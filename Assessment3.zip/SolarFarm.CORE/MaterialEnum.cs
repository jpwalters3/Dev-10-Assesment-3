﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SolarFarm.CORE
{
    public enum Materials
    {
        MULTI,
        MONO,
        AMORPH,
        CADT,
        COPS
    }
}